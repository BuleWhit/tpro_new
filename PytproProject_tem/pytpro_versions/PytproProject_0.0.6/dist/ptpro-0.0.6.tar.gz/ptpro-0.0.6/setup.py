from setuptools import setup

setup(
    name='ptpro',
    version='0.0.6'
)