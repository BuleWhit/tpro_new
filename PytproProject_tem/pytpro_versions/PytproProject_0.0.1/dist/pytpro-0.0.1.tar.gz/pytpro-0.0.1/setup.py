from setuptools import setup

setup(
    name='pytpro',
    version='0.0.1'
)