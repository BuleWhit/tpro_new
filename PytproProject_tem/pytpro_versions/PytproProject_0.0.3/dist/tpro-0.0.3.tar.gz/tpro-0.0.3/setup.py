from setuptools import setup

setup(
    name='tpro',
    version='0.0.3'
)